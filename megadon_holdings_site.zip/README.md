# Megadon Holdings Limited - African Attire Collection
Next.js project with integrated M-Pesa STK Push and Contact API.
